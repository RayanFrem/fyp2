import os
import shutil
from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
from langchain.vectorstores import Chroma
from langchain.llms import SentenceTransformers
from langchain.document_loaders import PDFLoader
from langchain.text_splitters import SentenceTransformersTokenTextSplitter
import pathlib
import textwrap
from IPython.display import display
from IPython.display import Markdown
import requests

app = Flask(__name__)
CORS(app)  

collection_name = "embeddedColl"
GOOGLE_API_KEY = "AIzaSyAj6iWH-zkPuv6reOne85Q8_7jpYP1vM9s"
genai.configure(api_key=GOOGLE_API_KEY)

client = Chroma("localhost", 8000)
model_name = "sentence-transformers/all-MiniLM-L12-v2"
llm = SentenceTransformers(model_name)
collection = client.get_or_create_collection(name=collection_name)
gemini_model = genai.GenerativeModel('gemini-pro')
base_path = '../'

#Below are functions written to handle calls inside teh app.py file 
def embed_sentence(sentence):
    embedding = llm.encode(sentence)
    return jsonify(embedding.tolist())

def search_similar(sentence):
    embedding = llm.encode(sentence)
    results = collection.search(embedding)
    return jsonify(results)


#Below are functions written to handle API calls from the React endpoint
@app.route('/get-gemini-answer', methods=['POST'])
def get_gemini_answer():
   data = request.json
   prompt = data['prompt']
   prompt = embed_sentence(prompt)
   context = search_similar(prompt)
   response = gemini_model.generate_content(f"{prompt} Contexte: {context}")
   answer = response.text
   return jsonify(answer)

@app.route('/get-gemini-suggestions', methods=['POST'])
def get_gemini_suggestions():
   data = request.json
   question = data['question']
   answer = data['answer']
   prompt = "La question en français est : " + str(question) + "Le bot a répondu :" + str(answer) + " En se basant sur la question et cette réponse, suggérez trois questions courte (10 mots) de suivi en français, couvrant différents types de questions scientifique. Donnez seulement les questions "
   suggested_questions = gemini_model.generate_content(prompt)
   suggested_questions = suggested_questions.text
   question1, question2, question3 = suggested_questions.split('\n')[:3]
   return jsonify(question1, question2, question3)

@app.route('/embed-sentence', methods=['POST'])
def embed_sentence():
    data = request.json
    sentence = data['sentence']
    embedding = llm.encode(sentence)
    return jsonify(embedding.tolist())

@app.route('/add-chunk', methods=['POST'])
def add_chunk():
    data = request.json
    sentence = data['sentence']
    text_splitter = SentenceTransformersTokenTextSplitter(
        chunk_overlap=0.1, model_name=model_name, tokens_per_chunk=200
    )
    chunks = text_splitter.split_text(sentence)

    vectorstore = Chroma(
        documents=chunks,
        collection_name=collection_name,
        embedding=llm,
    )
    vectorstore.add_documents()
    return jsonify({'status': 'success', 'message': 'Chunks added and indexed'})

@app.route('/search-similar', methods=['POST'])
def search_similar():
    data = request.json
    sentence = data['sentence']
    embedding = llm.encode(sentence)
    results = collection.search(embedding)
    return jsonify(results)


@app.route('/view-indexed', methods=['GET'])
def view_indexed():
    all_data = collection.get(limit=5)
    return jsonify(all_data)

if __name__ == '__main__':
    untreated_dir = os.path.join(base_path, 'untreated')
    chunked_dir = os.path.join(base_path, 'chunked')
    app.run(debug=True, port=5000)
