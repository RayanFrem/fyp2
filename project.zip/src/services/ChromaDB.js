async function insertChunk(chunk) {
    const response = await fetch('http://localhost:5000/insert-chunk', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ chunk })
    });
    const result = await response.json();
    return result;
  }
  
  async function searchSimilar(embeddedChunk) {
    const response = await fetch('http://localhost:5000/search-similar', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ embeddedChunk })
    });
    const result = await response.json();
    return result.similar_contexts;
  }
  
  module.exports = {
    insertChunk,
    searchSimilar
  };
  