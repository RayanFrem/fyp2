import React from 'react';

const LLMAnswer = ({ answer }) => {
  return (
    <div className="llm-answer">
      <h2>LLM Answer</h2>
      <p>{answer}</p>
    </div>
  );
};

export default LLMAnswer;
