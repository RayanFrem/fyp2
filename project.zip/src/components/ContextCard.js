import React from 'react';

const ContextCard = ({ context }) => {
  return (
    <div className="context-card">
      <h2>Context</h2>
      <p>{context}</p>
    </div>
  );
};

export default ContextCard;
