import React, { useState, useEffect } from 'react';
import './App.css';
import ContextCard from './components/ContextCard';
import LLMAnswer from './components/LLMAnswer';
import SuggestionItem from './components/SuggestionItem';
import {getGeminiAnswer, getGeminiSuggestions} from './services/GeminiAPI.js';
import embedChunk from './services/SentenceTransformer.js';
import getRelevantContext from './services/ConversationHistory.js';

function App() {
  const [prompt, setPrompt] = useState('');
  const [context, setContext] = useState('');
  const [answer, setAnswer] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const embedding = await embedChunk(prompt);

    const retrievedContext = await getRelevantContext(embedding);
    setContext(retrievedContext);

    const response = await getGeminiAnswer(prompt, retrievedContext);
    setAnswer(response.answer);

    const suggestionResponse = await getGeminiSuggestions(prompt, retrievedContext);
    setSuggestions(suggestionResponse.suggestions);
  };


  return (
    <div className="chatbot-container">
      <header>
        <h1>FYP2 Biology Chatbot</h1>
      </header>
      <div className="message-area">
        {context && (
          <div className="system-message">
            <ContextCard context={context} />
          </div>
        )}
        {answer && (
          <div className="system-message">
            <LLMAnswer answer={answer} />
          </div>
        )}
      </div>

      <div className="input-container">
        <form onSubmit={handleSubmit}>
          <textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          <button type="submit">Send</button>
        </form>
      </div>

      {suggestions.length > 0 && (
        <div className="suggestions">
          <h2>Suggestions</h2>
          <ul>
            {suggestions.map((suggestion) => (
              <SuggestionItem
                key={suggestion}
                suggestion={suggestion}
                handleClick={() => setPrompt(suggestion)}
              />
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
