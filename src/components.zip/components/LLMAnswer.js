import React from 'react';

const LLMAnswer = ({ answer }) => {
  return (
    <ul id="chatbox" className="chatbox">
  <li className="chat outgoing">
       <p>{answer}</p>
  </li>
</ul>
  );
};


export default LLMAnswer;
