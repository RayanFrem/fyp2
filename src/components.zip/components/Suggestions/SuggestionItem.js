import React from 'react';
import './SuggestionItem.css';

const SuggestionItem = ({ suggestion, handleClick }) => {
  return (
    <li className="suggestion-item">
      <button onClick={handleClick}>{suggestion}</button>
    </li>
  );
};

export default SuggestionItem;
