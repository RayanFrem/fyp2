import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowDown } from '@fortawesome/free-solid-svg-icons';

const Question = ({ prompt, showPrompt }) => {
  if (!showPrompt) {
    return null; 
  }

  return (
      <p>{prompt}</p>
  );
};

export default Question;
